package executor

import (
	"clampany/internal"
	"os/exec"
)

type AIExecutor struct {
	Role       internal.Role
	OutputDir  string
	SaveOutput bool
	PaneID     string // 割り当てられたtmuxペインID
}

func (e *AIExecutor) Execute(prompt string) error {
	sendCmd := exec.Command("tmux", "send-keys", "-t", e.PaneID, prompt, "C-m")
	return sendCmd.Run()
}
