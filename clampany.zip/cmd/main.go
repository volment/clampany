package cmd

import (
	"clampany/internal/executor"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"syscall"
)

// 仮: ロール一覧（本来はroles.yaml等から動的取得）
var aiRoles = []string{"ceo1", "pm1", "planner1", "engineer1", "engineer2"}

func main() {
	// 1. ロールごとにペイン生成＋claude起動＋ラベル付与
	paneMap := map[string]string{}
	for _, role := range aiRoles {
		cmd := exec.Command("tmux", "split-window", "-v", "-P", "-F", "#{pane_id}", "bash")
		out, err := cmd.Output()
		if err != nil {
			fmt.Println("tmuxペイン作成失敗:", err)
			os.Exit(1)
		}
		paneID := string(out)
		paneID = string([]byte(paneID)[:len(paneID)-1]) // 改行除去
		paneMap[role] = paneID
		exec.Command("tmux", "select-pane", "-t", paneID, "-T", role).Run()
		exec.Command("tmux", "send-keys", "-t", paneID, "claude", "C-m").Run()
	}
	exec.Command("tmux", "select-layout", "tiled").Run()

	// 2. ロールごとにキュー(chan string)生成
	queues := map[string]chan string{}
	for _, role := range aiRoles {
		queues[role] = make(chan string, 100)
	}

	// 3. ロールごとに永続ワーカー起動
	for _, role := range aiRoles {
		go func(role string) {
			exec := &executor.AIExecutor{PaneID: paneMap[role]}
			for prompt := range queues[role] {
				exec.Execute(prompt)
			}
		}(role)
	}

	// 4. panes.json保存
	os.MkdirAll("run/latest", 0755)
	f, _ := os.Create("run/latest/panes.json")
	json.NewEncoder(f).Encode(paneMap)
	f.Close()

	fmt.Println("[Clampany] 全ロール永続ワーカー起動中。Ctrl+Cで終了")

	// 5. Ctrl+Cまで無限待機
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)
	<-c
	fmt.Println("[Clampany] 終了します")
}
